<?php include_once('./includes/header.php'); ?>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="login-box">
                <div class="logo text-center">
                    <img src="./assets/logo-removebg-preview.png" alt="logo">
                </div>
                <form action="./codigoAcceso/bCodigo.php" method="POST"> 
                    <div class="form-group">
                        <input type="text" name="codigo" class="form-control" placeholder="Ingrese su Código" pattern="[a-zA-Z0-9]+" maxlength="6" required>
                        <small style="color: hsl(120, 100%, 50%); display: block; text-align: center;">Solo se permiten letras y números.</small>
                    </div>
                    <div class="text-center">
                        <button type="submit" class="btn btn-primary">Enviar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include_once('./includes/footer.php'); ?>
