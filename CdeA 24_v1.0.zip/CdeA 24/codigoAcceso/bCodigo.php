<?php
include_once('../includes/db.php');

// Verifico si se envió un código
if(isset($_POST['codigo'])) {
    $codigo = $_POST['codigo'];

    // Consulta SQL para verificar si el código existe y está activo
    $sql = "SELECT * FROM codigos WHERE codigo_acceso = '$codigo' AND estado_expirado = FALSE AND baja = FALSE";
    $resultado = mysqli_query($conn, $sql);

    if(mysqli_num_rows($resultado) > 0) {

        // El código existe y está activo
        $fila = mysqli_fetch_assoc($resultado);
        $id_codigo = $fila['id'];
        $estado_codigo = $fila['estado'];

        if($estado_codigo) {
            
            // Actualizo el estado del código a FALSE en la base de datos
            $sql_update = "UPDATE codigos SET estado = FALSE WHERE id = $id_codigo";
            mysqli_query($conn, $sql_update);
            
            header('Location: fcodigoExitoOut.php');
            exit();
        } else {
            // Actualizo el estado del código a TRUE en la base de datos
            $sql_update = "UPDATE codigos SET estado = TRUE WHERE id = $id_codigo";
            mysqli_query($conn, $sql_update);

            // Redirecciono a la página de éxito
            header('Location: fcodigoExito.php');
            exit();
        }
    } else {
        // El código no existe o no está activo
        header('Location: fcodigoFail.php');
        exit();
    }
} else {
    // Si no se envió un código, redireccionar a la página de error
    header('Location: fcodigoFail.php');
    exit();
}
?>
