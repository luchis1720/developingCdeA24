<?php include_once('../includes/header.php'); ?>

<div class="container mt-5" style="color: red;">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="login-box">
                <div class="logo text-center">
                    <img src="../assets/logo-removebg-preview.png" alt="logo">
                </div>
                <div class="text-center">
                    <h2 >No se encontró el código en la base de datos</h2>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include_once('../includes/footer.php'); ?>
