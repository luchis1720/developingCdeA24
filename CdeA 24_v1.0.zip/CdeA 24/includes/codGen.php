<?php
include_once("db.php");

// Funcion para obtener la fecha de nacimiento de un alumno
function obtenerFechaNacimiento($dni) {
    global $conn;
    
    // Consulta SQL para obtener la fecha de nacimiento del alumno
    $sql = "SELECT fecha_nacimiento FROM alumnos WHERE dni = '$dni'";
    $resultado = mysqli_query($conn, $sql);
    $fila = mysqli_fetch_assoc($resultado);
    
    return $fila['fecha_nacimiento'];
}

// Funcion para calcular la edad actual de un alumno
function calcularEdad($fecha_nacimiento) {
    
    $fecha_actual = date('Y-m-d');
    $edad = date_diff(date_create($fecha_nacimiento), date_create($fecha_actual))->y;
    return $edad;
}

// Funcion para generar el código de acceso unico basado en el DNI y la edad del alumno
function generarCodigo($dni, $fecha_nacimiento) {
    
    // Obtengo la edad del alumno
    $edad = calcularEdad($fecha_nacimiento);
    
    // Multiplico el DNI por la edad para obtener un numero unico
    $codigo_acceso_numerico = intval($dni) * $edad;
    
    // Convierto el codigo numérico en un hash SHA-256
    $codigo_acceso_hash = hash('sha256', $codigo_acceso_numerico);
    
    // Tomo los ultimos 6 caracteres del hash SHA-256
    $codigo_acceso = substr($codigo_acceso_hash, -6);
    
    return $codigo_acceso;
}

// Funcion principal para generar el codigo de acceso
function generarCodigoAcceso($dni) {
    
    // Obtengo la fecha de nacimiento del alumno
    $fecha_nacimiento = obtenerFechaNacimiento($dni);
    
    // Genero el codigo de acceso unico
    $codigo_acceso = generarCodigo($dni, $fecha_nacimiento);
    
    return $codigo_acceso;
}
?>
