<?php

// Datos de conexion a la base de datos

$host = "localhost"; // servidor de base de datos
$dbname = "codaccesobeltran"; // nombre base de datos
$username = "root"; // usuario de la base de datos
$password = ""; // contraseña de la base de datos

// Creo la conexion
$conn = new mysqli($host, $username, $password, $dbname);

// Verifico la conexion
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}
?>
