<?php

include_once("db.php");
include_once("codGen.php");

// Obtengo la fecha actual
$fecha_actual = date("Y-m-d");

// Consulta SQL para seleccionar los codigos de acceso vigentes
$sql_codigos = "SELECT * FROM codigos WHERE estado = TRUE AND estado_expirado = FALSE AND baja = FALSE";
$resultado_codigos = mysqli_query($conn, $sql_codigos);

// Recorro los codigos de acceso
while ($fila = mysqli_fetch_assoc($resultado_codigos)) {
    // Obtener el año de la fecha de expiracion y el DNI del alumno
    $anio_expiracion = date('Y', strtotime($fila['fecha_expiracion']));
    $dni_alumno = $fila['dni_alumno'];

    // Obtener el año actual
    $anio_actual = date('Y');

    // Si el año de expiracion es igual al año actual, no generar un nuevo codigo para el mismo DNI
    if ($anio_expiracion == $anio_actual) {
        continue;
    }

    // Marco el codigo actual como expirado
    $id_codigo = $fila['id'];
    $sql_actualizar_codigo = "UPDATE codigos SET estado_expirado = TRUE WHERE id = $id_codigo";
    mysqli_query($conn, $sql_actualizar_codigo);

    // Genero un nuevo codigo de acceso para el mismo DNI
    $nuevo_codigo = generarCodigoAcceso($dni_alumno);

    // Inserto el nuevo codigo en la base de datos
    $nueva_fecha_expiracion = date('Y-m-d', strtotime('+1 year')); // Nueva fecha de expiracion
    $sql_insertar_codigo = "INSERT INTO codigos (codigo_acceso, dni_alumno, fecha_expiracion, estado, estado_expirado) VALUES ('$nuevo_codigo', '$dni_alumno', '$nueva_fecha_expiracion', TRUE, FALSE)";
    mysqli_query($conn, $sql_insertar_codigo);
}

// Cierro la conexion a la base de datos
mysqli_close($conn);
?>
