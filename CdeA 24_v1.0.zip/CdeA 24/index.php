<?php

include_once('./codigoAcceso/fCodigo.php');

?>
